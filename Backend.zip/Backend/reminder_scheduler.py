"""
reminder_scheduler.py
======================

Runs a background job that automatically checks, once a day, for:
  1. ANC Reminders    - mothers due for their next antenatal checkup
  2. Vaccination Due   - overdue child vaccinations

For each one found (that hasn't already been reminded recently), it
creates an alert row in the DB and sends the PHC an SMS + email via
notification_service.send_phc_notification() - the same mechanism
already used for the automatic High Risk Pregnancy alert in
app.py's /add_health_record.

------------------------------------------------------------------
IMPORTANT: this module opens its OWN database connection
------------------------------------------------------------------
db_config.py creates a single shared `db`/`cursor` at import time,
used by every Flask route. This scheduler runs on a separate
background thread (via APScheduler), and MySQL Connector/Python
cursors are NOT thread-safe - sharing db_config's cursor here would
let a background scheduler run collide with a live Flask request
using the same cursor at the same time, causing exactly the
symptoms this was built to fix: requests hanging for a long time,
then coming back blank/corrupted.

So every function below opens a short-lived connection of its own
via _get_connection(), does its work, and closes it - it never
imports or touches db_config's shared cursor.

------------------------------------------------------------------
SETUP
------------------------------------------------------------------
1. Install the scheduler library:
       pip install apscheduler

2. In app.py, add near the other imports:
       from reminder_scheduler import start_scheduler

   and right after app.register_blueprint(chatbot_bp), add:
       start_scheduler()

That's it. The checks run once immediately when the server starts
(so you can see it work right away during testing), then again
every 24 hours for as long as the server keeps running.

------------------------------------------------------------------
A note on the ANC reminder logic
------------------------------------------------------------------
The `mother` table only stores pregnancy_month as a plain number -
there's no date column tracking when that was recorded. So this
can't calculate "days until her next visit" precisely; instead it
flags mothers whose pregnancy_month matches one of India's standard
ANC checkup windows (roughly months 3, 6, and 8), and avoids
re-sending the same reminder more than once every 25 days so it
reads as a periodic nudge rather than a daily spam of the same
message. Adjust ANC_CHECKUP_MONTHS below if your ASHA program
follows a different schedule.
"""

import atexit
import os
from datetime import datetime, timedelta

import mysql.connector
from apscheduler.schedulers.background import BackgroundScheduler
from dotenv import load_dotenv

from notification_service import send_phc_notification

load_dotenv()

# Standard ANC checkup months (simplified to whole months since
# pregnancy_month is stored as a single integer, not a date).
ANC_CHECKUP_MONTHS = (3, 6, 8)

# Minimum days between repeat reminders for the same mother/child,
# so someone who stays "due" isn't messaged every single day.
ANC_REMINDER_COOLDOWN_DAYS = 25
VACCINE_REMINDER_COOLDOWN_DAYS = 7


def _get_connection():
    """Opens a fresh, short-lived DB connection dedicated to this
    background thread - never shares db_config's global cursor."""
    return mysql.connector.connect(
        host=os.getenv("DB_HOST", "localhost"),
        user=os.getenv("DB_USER", "root"),
        password=os.getenv("DB_PASSWORD", ""),
        database=os.getenv("DB_NAME", "maatrisakhi_db"),
    )


def _already_reminded(cursor, alert_type, mother_id=None, child_id=None, cooldown_days=7):
    """True if an alert of this type was already created for this
    mother/child within the cooldown window."""
    cutoff = datetime.now() - timedelta(days=cooldown_days)

    query = "SELECT alert_id FROM alert WHERE alert_type = %s AND alert_date >= %s"
    params = [alert_type, cutoff]

    if mother_id is not None:
        query += " AND mother_id = %s"
        params.append(mother_id)

    if child_id is not None:
        query += " AND child_id = %s"
        params.append(child_id)

    query += " LIMIT 1"

    cursor.execute(query, tuple(params))
    return cursor.fetchone() is not None


def _create_alert_and_notify(conn, cursor, mother_id, child_id, alert_type, message):
    cursor.execute(
        """
        INSERT INTO alert (mother_id, child_id, alert_type, message)
        VALUES (%s, %s, %s, %s)
        """,
        (mother_id, child_id, alert_type, message),
    )
    conn.commit()

    result = send_phc_notification(message)

    print("------------------------------------")
    print(f"{alert_type} ALERT CREATED")
    print("Mother ID:", mother_id, "| Child ID:", child_id)
    print("SMS Sent:", result["sms_sent"], "| Email Sent:", result["email_sent"])
    print("------------------------------------")


def check_anc_reminders(conn, cursor):
    """Finds mothers at a standard ANC checkup month and notifies
    the PHC, unless already reminded recently."""
    try:
        placeholders = ", ".join(["%s"] * len(ANC_CHECKUP_MONTHS))
        cursor.execute(
            f"""
            SELECT mother_id, name, village, pregnancy_month
            FROM mother
            WHERE pregnancy_month IN ({placeholders})
            """,
            ANC_CHECKUP_MONTHS,
        )
        due_mothers = cursor.fetchall()

        for mother_id, name, village, pregnancy_month in due_mothers:
            if _already_reminded(
                cursor,
                "ANC Reminder",
                mother_id=mother_id,
                cooldown_days=ANC_REMINDER_COOLDOWN_DAYS,
            ):
                continue

            message = (
                f"ANC Reminder: {name} (Village: {village}) is in "
                f"pregnancy month {pregnancy_month} and is due for an "
                f"antenatal checkup at the PHC."
            )
            _create_alert_and_notify(conn, cursor, mother_id, None, "ANC Reminder", message)

    except Exception as e:
        print("ANC reminder check failed:", e)


def check_vaccination_reminders(conn, cursor):
    """Finds overdue child vaccinations and notifies the PHC, unless
    already reminded recently for that same dose."""
    try:
        cursor.execute(
            """
            SELECT v.child_id, c.child_name, v.vaccine_name,
                   v.dose_number, v.due_date
            FROM vaccination v
            JOIN child c ON c.child_id = v.child_id
            WHERE v.status = 'Pending'
            AND v.due_date < CURDATE()
            """
        )
        overdue = cursor.fetchall()

        for child_id, child_name, vaccine_name, dose_number, due_date in overdue:
            if _already_reminded(
                cursor,
                "Vaccination Due",
                child_id=child_id,
                cooldown_days=VACCINE_REMINDER_COOLDOWN_DAYS,
            ):
                continue

            message = (
                f"Vaccination Due: {child_name} missed {vaccine_name} "
                f"(dose {dose_number}), which was due on {due_date}. "
                f"Please follow up."
            )
            _create_alert_and_notify(conn, cursor, None, child_id, "Vaccination Due", message)

    except Exception as e:
        print("Vaccination reminder check failed:", e)


def run_daily_checks():
    print("Running daily ANC + vaccination reminder checks...")

    conn = None
    try:
        conn = _get_connection()
        cursor = conn.cursor()
        check_anc_reminders(conn, cursor)
        check_vaccination_reminders(conn, cursor)
        cursor.close()
    except Exception as e:
        print("Reminder scheduler could not connect to the database:", e)
    finally:
        if conn is not None and conn.is_connected():
            conn.close()


_scheduler = None


def start_scheduler():
    """Starts the background scheduler. Safe to call once at app
    startup. Flask's debug auto-reloader runs app.py in two
    processes; this only starts the scheduler in the actual worker
    process (WERKZEUG_RUN_MAIN) so jobs don't run twice."""
    global _scheduler

    if _scheduler is not None:
        return

    if os.environ.get("WERKZEUG_RUN_MAIN") == "false":
        # This is Werkzeug's initial parent process during debug
        # reload - the real worker process will call this again.
        return

    _scheduler = BackgroundScheduler()
    _scheduler.add_job(run_daily_checks, "interval", hours=24, id="daily_reminders")
    _scheduler.start()

    # Run once immediately on startup too, so you can see it work
    # right away instead of waiting 24 hours during testing.
    run_daily_checks()

    atexit.register(lambda: _scheduler.shutdown(wait=False))
