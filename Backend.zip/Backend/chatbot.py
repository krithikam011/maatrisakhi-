"""
chatbot.py
==========

In-app "how do I use this app" assistant for the MaatriSakhi backend.
Uses Google's Gemini API via the current `google-genai` SDK (the
official replacement for the now fully-deprecated
`google-generativeai` package).

------------------------------------------------------------------
SETUP
------------------------------------------------------------------
1. Install the SDK (from the Backend folder, same venv as the rest):
       pip uninstall google-generativeai -y
       pip install google-genai

2. Get a free Gemini API key: https://aistudio.google.com/app/apikey

3. Add this line to your existing .env file (same folder as app.py):
       GEMINI_API_KEY=your_key_here

That's it — app.py already imports and registers this blueprint,
so POST http://127.0.0.1:5000/chatbot is live once you restart the
server. This matches exactly what ApiService.askChatbot() in the
Flutter app calls.

------------------------------------------------------------------
Request format (sent by the app)
------------------------------------------------------------------
    POST /chatbot
    {
      "message": "How do I register a mother?",
      "history": [
        {"role": "user", "text": "..."},
        {"role": "bot",  "text": "..."}
      ]
    }

Response:
    { "reply": "Tap 'Register mother' on the home screen, then..." }
"""

import os

from dotenv import load_dotenv
from flask import Blueprint, jsonify, request

load_dotenv()

chatbot_bp = Blueprint("chatbot", __name__)

# Current stable Gemini model (as of mid-2026). gemini-2.5-flash is
# also stable today but is scheduled to shut down 16 Oct 2026, so
# this one avoids needing to change it again shortly.
GEMINI_MODEL = "gemini-3.1-flash-lite"

# ---------------------------------------------------------------
# System prompt: keeps the bot on-topic (app usage only) and gives
# it accurate knowledge of what this specific app can do. Update
# this whenever you add/rename a screen, field, or endpoint.
# ---------------------------------------------------------------
SYSTEM_PROMPT = """
You are the in-app assistant for MaatriSakhi, a Flutter app used by
ASHA (Accredited Social Health Activist) workers in India to manage
maternal and child health records.

Your ONLY job is to help the ASHA worker understand how to use the
app itself — where to tap, what a field is for, how a feature works.
You are NOT a medical assistant: if asked a medical question (e.g.
"is this blood pressure dangerous?"), politely say that's outside
what you can help with and suggest they consult a doctor or their
supervisor, then redirect to what you can help with.

Keep answers short (2-4 sentences), step-by-step where useful, and
in plain, simple language — many users are not highly technical.
Reply in the same language the user's message is written in
(English, Hindi, or Kannada).

Here is exactly what the app can do:

- Home screen: shows quick stats (total mothers, high-risk cases,
  overdue vaccinations) and shortcuts to every screen below. A
  floating chat icon (bottom-right) opens this assistant from
  anywhere in the app.

- Register mother: a form with full name, age, phone number,
  village, and pregnancy month. Tap "Save mother profile" to submit.
  If there's no internet, it saves on the device and a "Sync offline
  records" button sends it once back online.

- Mother records: lists every registered mother. Tap a record to
  edit any field (name, age, phone, village, pregnancy month), or
  delete the record entirely.

- Health screening: enter a mother's vitals — systolic blood
  pressure, diastolic blood pressure, blood sugar (with a unit
  toggle between mmol/L and mg/dL), body temperature, and heart
  rate — then tap "Predict & save". The app's machine learning
  model returns a risk level (Low, Mid, or High Risk) with a
  recommendation, and there's a speaker icon to have the result
  read aloud. If the result comes back High Risk, the app
  automatically creates an alert and notifies the PHC (Primary
  Health Centre) by SMS and email — no extra action needed from
  the ASHA worker.

- Child profile: register a child by linking them to a mother,
  entering their full name, gender, and date of birth (DD/MM/YYYY).

- Vaccine tracker: shows a child's due and overdue vaccines based
  on their age, and lets the worker record a vaccination date and
  mark doses as completed.

- Alerts: lists all alerts — high-risk pregnancy cases and overdue
  vaccinations — with their status.

- Every text field in the app (names, dates, numbers) has a
  microphone icon — tap it to fill that field by speaking instead
  of typing, in the currently selected language.

- The language selector on the home screen switches the entire app
  between English, Hindi, and Kannada instantly, including all
  field names and headings.

- Dashboard: an overview screen showing total mothers, total
  children, high-risk cases, and overdue vaccinations at a glance.

If a user asks something not covered above, say you're not sure and
suggest they check with their supervisor, rather than guessing.
""".strip()


def _build_history(history):
    """Convert the app's [{"role","text"}, ...] into the SDK's
    [{"role","parts"}, ...] format. The SDK uses 'model' instead of
    'bot' for the assistant's turns."""
    converted = []
    for turn in history or []:
        role = "model" if turn.get("role") == "bot" else "user"
        text = turn.get("text", "")
        if text:
            converted.append({"role": role, "parts": [{"text": text}]})
    return converted


@chatbot_bp.route("/chatbot", methods=["POST"])
def chatbot():
    data = request.get_json(silent=True) or {}
    message = (data.get("message") or "").strip()
    history = data.get("history") or []

    if not message:
        return jsonify({"reply": "Please type or speak a question."}), 400

    api_key = os.environ.get("GEMINI_API_KEY")
    if not api_key:
        return jsonify(
            {"reply": "Assistant is not configured yet (missing GEMINI_API_KEY)."}
        ), 500

    try:
        from google import genai
        from google.genai import types

        client = genai.Client(api_key=api_key)

        chat = client.chats.create(
            model=GEMINI_MODEL,
            history=_build_history(history),
            config=types.GenerateContentConfig(system_instruction=SYSTEM_PROMPT),
        )
        response = chat.send_message(message)

        return jsonify({"reply": response.text.strip()})

    except Exception as e:  # noqa: BLE001 - surfacing any SDK error as a reply
        print(f"Chatbot error: {e}")
        return jsonify(
            {"reply": "Sorry, I ran into an error. Please try again in a moment."}
        ), 500
