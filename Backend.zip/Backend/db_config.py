import mysql.connector
import os
from dotenv import load_dotenv

load_dotenv()

DB_CONFIG = dict(
    host=os.getenv("DB_HOST", "localhost"),
    user=os.getenv("DB_USER", "root"),
    password=os.getenv("DB_PASSWORD", ""),
    database=os.getenv("DB_NAME", "maatrisakhi_db"),
    # Fails fast instead of hanging for a long time if MySQL is
    # unreachable - without this, a dead/unreachable server can
    # make a connection attempt hang far longer than feels sane.
    connection_timeout=5,
)


def get_connection():
    """Opens a brand new MySQL connection. Call this once per
    request (see app.py's before_request/teardown_request) instead
    of sharing one long-lived connection across the whole app's
    life - a fresh connection can't go stale, so there's nothing
    to ping or detect."""
    return mysql.connector.connect(**DB_CONFIG)


# Kept so a startup print still confirms the DB is reachable at
# boot, same as before - this connection is only used for that
# one check and then closed; it is NOT what routes use to query.
_startup_conn = get_connection()
_startup_conn.close()

print("MySQL Connected Successfully")