from flask import Flask, request, jsonify, send_from_directory, g
from datetime import datetime, date
from flask_cors import CORS

import os
import pickle

from db_config import get_connection
from notification_service import send_phc_notification
from chatbot import chatbot_bp
from reminder_scheduler import start_scheduler


# ============================================================
# FLASK APP
# ============================================================

app = Flask(__name__)

CORS(app)

# Each request gets its own connection/cursor, stored on Flask's
# request-local `g` object (NOT a module-level global). A plain
# module-level global would be shared and get stomped on if two
# requests overlap at all (this dashboard page fires several
# fetches at once on load) - `g` is specifically designed to be
# safe per-request, even under concurrent handling. A fresh
# connection per request also avoids the stale-connection hangs a
# long-lived connection runs into after being idle for a while.


@app.before_request
def _open_db_connection():
    g.db = get_connection()
    g.cursor = g.db.cursor()


@app.teardown_request
def _close_db_connection(exception=None):
    db_conn = g.pop("db", None)
    db_cursor = g.pop("cursor", None)
    try:
        if db_cursor is not None:
            db_cursor.close()
    except Exception:
        pass
    try:
        if db_conn is not None and db_conn.is_connected():
            db_conn.close()
    except Exception:
        pass



app.register_blueprint(chatbot_bp)

start_scheduler()


# ============================================================
# LOAD ML MODEL
# ============================================================

model = pickle.load(
    open("maternal_risk_model.pkl", "rb")
)


# ============================================================
# HOME
# ============================================================

@app.route("/")
def home():

    return "MaatriSakhi Backend Running Successfully"


@app.route("/phc")
def phc_dashboard():

    static_dir = os.path.join(app.root_path, "static")
    file_path = os.path.join(static_dir, "phc_dashboard.html")

    print("------------------------------------")
    print("PHC dashboard requested")
    print("Looking for file at:", file_path)
    print("File exists:", os.path.isfile(file_path))
    print("------------------------------------")

    return send_from_directory(static_dir, "phc_dashboard.html")


# ============================================================
# PREDICTION ROUTE
# ============================================================

@app.route("/predict", methods=["POST"])
def predict():

    try:

        data = request.get_json()

        features = [[
            data["Age"],
            data["SystolicBP"],
            data["DiastolicBP"],
            data["BS"],
            data["BodyTemp"],
            data["HeartRate"]
        ]]

        prediction = model.predict(features)

        risk = str(prediction[0])

        if risk.lower() == "high risk":

            recommendation = (
                "High Risk Pregnancy. "
                "Consult doctor immediately and monitor health regularly."
            )

        elif risk.lower() == "mid risk":

            recommendation = (
                "Moderate Risk Pregnancy. "
                "Regular checkups and proper care are recommended."
            )

        else:

            recommendation = (
                "Low Risk Pregnancy. "
                "Continue routine checkups and maintain a healthy lifestyle."
            )

        return jsonify({
            "RiskLevel": risk,
            "Recommendation": recommendation
        })

    except Exception as e:

        print("PREDICTION ERROR:", e)

        return jsonify({
            "error": str(e)
        }), 500


# ============================================================
# ADD MOTHER
# ============================================================

@app.route("/add_mother", methods=["POST"])
def add_mother():

    try:

        data = request.get_json()

        print("Received Mother Data:", data)

        name = data.get("name")
        age = data.get("age")
        phone = data.get("phone")
        village = data.get("village")
        pregnancy_month = data.get("pregnancy_month")

        sql = """
        INSERT INTO mother
        (
            name,
            age,
            phone,
            village,
            pregnancy_month
        )
        VALUES (%s,%s,%s,%s,%s)
        """

        values = (
            name,
            age,
            phone,
            village,
            pregnancy_month
        )

        g.cursor.execute(sql, values)

        g.db.commit()

        return jsonify({
            "message": "Mother Added Successfully"
        }), 200

    except Exception as e:

        g.db.rollback()

        print("ADD MOTHER ERROR:", e)

        return jsonify({
            "error": str(e)
        }), 500


# ============================================================
# GET MOTHERS
# ============================================================

@app.route("/get_mothers", methods=["GET"])
def get_mothers():

    try:

        g.cursor.execute("""
            SELECT
                mother_id,
                name,
                age,
                phone,
                village,
                pregnancy_month
            FROM mother
        """)

        mothers = g.cursor.fetchall()

        mother_list = []

        for mother in mothers:

            mother_list.append({

                "mother_id": mother[0],

                "name": mother[1],

                "age": mother[2],

                "phone": mother[3],

                "village": mother[4],

                "pregnancy_month": mother[5]

            })

        return jsonify(mother_list)

    except Exception as e:

        return jsonify({
            "error": str(e)
        }), 500


# ============================================================
# UPDATE MOTHER
# ============================================================

@app.route("/update_mother/<int:mother_id>", methods=["PUT"])
def update_mother(mother_id):

    try:

        data = request.get_json()

        name = data["name"]
        age = data["age"]
        phone = data["phone"]
        village = data["village"]
        pregnancy_month = data["pregnancy_month"]

        g.cursor.execute("""
            UPDATE mother
            SET
                name=%s,
                age=%s,
                phone=%s,
                village=%s,
                pregnancy_month=%s
            WHERE mother_id=%s
        """, (
            name,
            age,
            phone,
            village,
            pregnancy_month,
            mother_id
        ))

        g.db.commit()

        return jsonify({
            "message": "Mother Updated Successfully"
        }), 200

    except Exception as e:

        g.db.rollback()

        print("UPDATE MOTHER ERROR:", e)

        return jsonify({
            "error": str(e)
        }), 500


# ============================================================
# DELETE MOTHER
# ============================================================

@app.route("/delete_mother/<int:mother_id>", methods=["DELETE"])
def delete_mother(mother_id):

    try:

        # Delete vaccinations
        g.cursor.execute("""
            DELETE v
            FROM vaccination v
            JOIN child c
            ON v.child_id = c.child_id
            WHERE c.mother_id = %s
        """, (mother_id,))

        # Delete alerts
        g.cursor.execute("""
            DELETE FROM alert
            WHERE mother_id = %s
        """, (mother_id,))

        # Delete children
        g.cursor.execute("""
            DELETE FROM child
            WHERE mother_id = %s
        """, (mother_id,))

        # Delete health records
        g.cursor.execute("""
            DELETE FROM health_record
            WHERE mother_id = %s
        """, (mother_id,))

        # Delete mother
        g.cursor.execute("""
            DELETE FROM mother
            WHERE mother_id = %s
        """, (mother_id,))

        g.db.commit()

        return jsonify({
            "message": "Mother deleted successfully"
        }), 200

    except Exception as e:

        g.db.rollback()

        print("DELETE MOTHER ERROR:", e)

        return jsonify({
            "error": str(e)
        }), 500


# ============================================================
# ADD HEALTH RECORD + AUTOMATIC PHC ALERT
# ============================================================

@app.route("/add_health_record", methods=["POST"])
def add_health_record():

    try:

        data = request.get_json()

        mother_id = data["mother_id"]

        # ----------------------------------------------------
        # GET MOTHER DETAILS
        # ----------------------------------------------------

        g.cursor.execute("""
            SELECT
                name,
                age,
                phone,
                village,
                pregnancy_month
            FROM mother
            WHERE mother_id = %s
        """, (mother_id,))

        mother = g.cursor.fetchone()

        if mother is None:

            return jsonify({
                "error": "Mother not found"
            }), 404

        mother_name = mother[0]
        mother_age = mother[1]
        mother_phone = mother[2]
        mother_village = mother[3]
        pregnancy_month = mother[4]

        # ----------------------------------------------------
        # USE AGE FROM MOTHER TABLE
        # ----------------------------------------------------

        age = mother_age

        # ----------------------------------------------------
        # ML FEATURES
        # ----------------------------------------------------

        features = [[
            age,
            data["SystolicBP"],
            data["DiastolicBP"],
            data["BS"],
            data["BodyTemp"],
            data["HeartRate"]
        ]]

        # ----------------------------------------------------
        # PREDICT RISK
        # ----------------------------------------------------

        prediction = model.predict(features)

        risk = str(prediction[0])

        # ----------------------------------------------------
        # RECOMMENDATION
        # ----------------------------------------------------

        if risk.lower() == "high risk":

            recommendation = (
                "High Risk Pregnancy. "
                "Consult doctor immediately."
            )

        elif risk.lower() == "mid risk":

            recommendation = (
                "Moderate Risk Pregnancy. "
                "Regular checkups needed."
            )

        else:

            recommendation = (
                "Low Risk Pregnancy. "
                "Maintain healthy lifestyle."
            )

        # ----------------------------------------------------
        # SAVE HEALTH RECORD
        # ----------------------------------------------------

        sql = """
        INSERT INTO health_record
        (
            mother_id,
            Age,
            SystolicBP,
            DiastolicBP,
            BS,
            BodyTemp,
            HeartRate,
            RiskLevel
        )
        VALUES (%s,%s,%s,%s,%s,%s,%s,%s)
        """

        values = (
            mother_id,
            age,
            data["SystolicBP"],
            data["DiastolicBP"],
            data["BS"],
            data["BodyTemp"],
            data["HeartRate"],
            risk
        )

        g.cursor.execute(sql, values)

        g.db.commit()

        # ====================================================
        # AUTOMATIC HIGH RISK ALERT
        # ====================================================

        alert_created = False
        sms_sent = False
        email_sent = False

        if risk.lower() == "high risk":

            alert_message = (
                f"High Risk Pregnancy detected for {mother_name}. "
                f"Village: {mother_village}. "
                f"Pregnancy Month: {pregnancy_month}. "
                f"Age: {age}. "
                f"Immediate medical attention required at PHC."
            )

            # ------------------------------------------------
            # SAVE ALERT TO MYSQL
            # ------------------------------------------------

            g.cursor.execute("""
                INSERT INTO alert
                (
                    mother_id,
                    child_id,
                    alert_type,
                    message
                )
                VALUES (%s,%s,%s,%s)
            """, (
                mother_id,
                None,
                "High Risk Pregnancy",
                alert_message
            ))

            g.db.commit()

            alert_created = True

            # ------------------------------------------------
            # SEND SMS + EMAIL
            # ------------------------------------------------

            notification_result = send_phc_notification(
                alert_message
            )

            sms_sent = notification_result["sms_sent"]

            email_sent = notification_result["email_sent"]

            print("------------------------------------")
            print("HIGH RISK ALERT CREATED")
            print("Mother:", mother_name)
            print("Mother ID:", mother_id)
            print("SMS Sent:", sms_sent)
            print("Email Sent:", email_sent)
            print("------------------------------------")

        # ====================================================
        # RESPONSE TO FLUTTER
        # ====================================================

        return jsonify({

            "RiskLevel": risk,

            "Recommendation": recommendation,

            "message": "Health Record Saved Successfully",

            "alert_created": alert_created,

            "sms_sent": sms_sent,

            "email_sent": email_sent

        }), 200

    except Exception as e:

        g.db.rollback()

        print("HEALTH RECORD ERROR:", e)

        return jsonify({
            "error": str(e)
        }), 500


# ============================================================
# GET HEALTH RECORD
# ============================================================

@app.route("/get_health_record/<int:mother_id>", methods=["GET"])
def get_health_record(mother_id):

    try:

        g.cursor.execute("""
            SELECT
                record_id,
                mother_id,
                Age,
                SystolicBP,
                DiastolicBP,
                BS,
                BodyTemp,
                HeartRate,
                RiskLevel
            FROM health_record
            WHERE mother_id = %s
        """, (mother_id,))

        records = g.cursor.fetchall()

        health_records = []

        for record in records:

            health_records.append({

                "record_id": record[0],

                "mother_id": record[1],

                "Age": record[2],

                "SystolicBP": record[3],

                "DiastolicBP": record[4],

                "BS": record[5],

                "BodyTemp": record[6],

                "HeartRate": record[7],

                "RiskLevel": record[8]

            })

        return jsonify(health_records)

    except Exception as e:

        return jsonify({
            "error": str(e)
        }), 500


# ============================================================
# ADD CHILD
# ============================================================

@app.route("/add_child", methods=["POST"])
def add_child():

    try:

        data = request.get_json()

        # The app sends the date as DD/MM/YYYY, but MySQL's DATE
        # column expects YYYY-MM-DD - convert here so the insert
        # doesn't fail with "Incorrect date value".
        raw_dob = data["dob"]

        try:
            dob_for_db = datetime.strptime(raw_dob, "%d/%m/%Y").strftime("%Y-%m-%d")
        except ValueError:
            # Already in YYYY-MM-DD (or something else) - fall back
            # to using it as-is rather than failing here.
            dob_for_db = raw_dob

        g.cursor.execute("""
            INSERT INTO child
            (
                mother_id,
                child_name,
                gender,
                dob
            )
            VALUES (%s,%s,%s,%s)
        """, (
            data["mother_id"],
            data["child_name"],
            data["gender"],
            dob_for_db
        ))

        g.db.commit()

        return jsonify({
            "message": "Child Added Successfully"
        }), 200

    except Exception as e:

        g.db.rollback()

        return jsonify({
            "error": str(e)
        }), 500


# ============================================================
# GET CHILDREN
# ============================================================

@app.route("/get_children", methods=["GET"])
def get_children():

    try:

        g.cursor.execute("SELECT * FROM child")

        rows = g.cursor.fetchall()

        children = []

        for r in rows:

            children.append({

                "child_id": r[0],

                "mother_id": r[1],

                "child_name": r[2],

                "gender": r[3],

                "dob": r[4]

            })

        return jsonify(children)

    except Exception as e:

        return jsonify({
            "error": str(e)
        }), 500


# ============================================================
# DUE VACCINES
# ============================================================

@app.route("/get_due_vaccines/<int:child_id>", methods=["GET"])
def get_due_vaccines(child_id):

    try:

        g.cursor.execute("""
            SELECT child_name, dob
            FROM child
            WHERE child_id=%s
        """, (child_id,))

        child = g.cursor.fetchone()

        if child is None:

            return jsonify({
                "error": "Child not found"
            }), 404

        child_name = child[0]

        dob = child[1]

        if isinstance(dob, str):

            dob = datetime.strptime(
                dob,
                "%Y-%m-%d"
            ).date()

        today = date.today()

        age_months = (
            (today.year - dob.year) * 12
            +
            (today.month - dob.month)
        )

        due_vaccines = []

        if age_months <= 1:

            due_vaccines = [

                {
                    "vaccine_name": "BCG",
                    "dose_number": 1
                },

                {
                    "vaccine_name": "OPV-0",
                    "dose_number": 0
                },

                {
                    "vaccine_name": "Hepatitis B Birth Dose",
                    "dose_number": 1
                }

            ]

        elif age_months <= 2:

            due_vaccines = [

                {
                    "vaccine_name": "OPV-1",
                    "dose_number": 1
                },

                {
                    "vaccine_name": "Pentavalent-1",
                    "dose_number": 1
                },

                {
                    "vaccine_name": "Rotavirus-1",
                    "dose_number": 1
                },

                {
                    "vaccine_name": "PCV-1",
                    "dose_number": 1
                }

            ]

        elif age_months <= 3:

            due_vaccines = [

                {
                    "vaccine_name": "OPV-2",
                    "dose_number": 2
                },

                {
                    "vaccine_name": "Pentavalent-2",
                    "dose_number": 2
                },

                {
                    "vaccine_name": "Rotavirus-2",
                    "dose_number": 2
                }

            ]

        elif age_months <= 4:

            due_vaccines = [

                {
                    "vaccine_name": "OPV-3",
                    "dose_number": 3
                },

                {
                    "vaccine_name": "Pentavalent-3",
                    "dose_number": 3
                },

                {
                    "vaccine_name": "fIPV-2",
                    "dose_number": 2
                },

                {
                    "vaccine_name": "PCV-2",
                    "dose_number": 2
                }

            ]

        elif age_months <= 12:

            due_vaccines = [

                {
                    "vaccine_name": "MR-1",
                    "dose_number": 1
                },

                {
                    "vaccine_name": "JE-1 (Endemic Areas)",
                    "dose_number": 1
                }

            ]

        elif age_months <= 24:

            due_vaccines = [

                {
                    "vaccine_name": "MR-2",
                    "dose_number": 2
                },

                {
                    "vaccine_name": "DPT Booster-1",
                    "dose_number": 1
                },

                {
                    "vaccine_name": "OPV Booster",
                    "dose_number": 1
                }

            ]

        elif age_months <= 72:

            due_vaccines = [

                {
                    "vaccine_name": "DPT Booster-2",
                    "dose_number": 2
                }

            ]

        return jsonify({

            "child_name": child_name,

            "age_months": age_months,

            "due_vaccines": due_vaccines

        }), 200

    except Exception as e:

        return jsonify({
            "error": str(e)
        }), 500


# ============================================================
# ADD VACCINATION
# ============================================================

@app.route("/add_vaccination", methods=["POST"])
def add_vaccination():

    try:

        data = request.get_json()

        child_id = data["child_id"]

        vaccines = data["vaccines"]

        vaccination_date = data["vaccination_date"]

        for vaccine in vaccines:

            g.cursor.execute("""
                INSERT INTO vaccination
                (
                    child_id,
                    vaccine_name,
                    dose_number,
                    due_date,
                    vaccination_date,
                    status
                )
                VALUES (%s,%s,%s,%s,%s,%s)
            """, (
                child_id,
                vaccine["vaccine_name"],
                vaccine["dose_number"],
                vaccine["due_date"],
                vaccination_date,
                "Completed"
            ))

        g.db.commit()

        return jsonify({
            "message": "Vaccinations Saved Successfully"
        }), 200

    except Exception as e:

        g.db.rollback()

        return jsonify({
            "error": str(e)
        }), 500


# ============================================================
# GET VACCINATIONS
# ============================================================

@app.route("/get_vaccinations/<int:child_id>", methods=["GET"])
def get_vaccinations(child_id):

    try:

        g.cursor.execute("""
            SELECT
                vaccination_id,
                child_id,
                vaccine_name,
                dose_number,
                due_date,
                vaccination_date,
                status
            FROM vaccination
            WHERE child_id = %s
        """, (child_id,))

        records = g.cursor.fetchall()

        result = []

        for r in records:

            result.append({

                "vaccination_id": r[0],

                "child_id": r[1],

                "vaccine_name": r[2],

                "dose_number": r[3],

                "due_date": r[4],

                "vaccination_date": r[5],

                "status": r[6]

            })

        return jsonify(result)

    except Exception as e:

        return jsonify({
            "error": str(e)
        }), 500


# ============================================================
# OVERDUE VACCINATIONS
# ============================================================

@app.route("/overdue_vaccinations", methods=["GET"])
def overdue_vaccinations():

    try:

        g.cursor.execute("""
            SELECT
                vaccination_id,
                child_id,
                vaccine_name,
                dose_number,
                due_date,
                vaccination_date,
                status
            FROM vaccination
            WHERE status = 'Pending'
            AND due_date < CURDATE()
        """)

        records = g.cursor.fetchall()

        overdue_list = []

        for r in records:

            overdue_list.append({

                "vaccination_id": r[0],

                "child_id": r[1],

                "vaccine_name": r[2],

                "dose_number": r[3],

                "due_date": str(r[4]),

                "vaccination_date": r[5],

                "status": r[6],

                "alert":
                    "OVERDUE - Immediate attention required"

            })

        return jsonify({

            "total_overdue": len(overdue_list),

            "overdue_vaccinations": overdue_list

        })

    except Exception as e:

        return jsonify({
            "error": str(e)
        }), 500


# ============================================================
# MANUAL ALERT
# ============================================================

@app.route("/send_alert", methods=["POST"])
def send_alert():

    try:

        data = request.get_json()

        mother_id = data.get("mother_id")

        child_id = data.get("child_id")

        alert_type = data.get("alert_type")

        message = data.get("message")

        g.cursor.execute("""
            INSERT INTO alert
            (
                mother_id,
                child_id,
                alert_type,
                message
            )
            VALUES (%s,%s,%s,%s)
        """, (
            mother_id,
            child_id,
            alert_type,
            message
        ))

        g.db.commit()

        notification_result = send_phc_notification(message)

        return jsonify({

            "message": "Alert sent successfully",

            "status": "SUCCESS",

            "sms_sent": notification_result["sms_sent"],

            "email_sent": notification_result["email_sent"]

        }), 200

    except Exception as e:

        g.db.rollback()

        return jsonify({
            "error": str(e)
        }), 500


# ============================================================
# GET ALERTS
# ============================================================

@app.route("/get_alerts", methods=["GET"])
def get_alerts():

    try:

        g.cursor.execute("""
            SELECT
                alert_id,
                mother_id,
                child_id,
                alert_type,
                message,
                alert_date,
                status
            FROM alert
            ORDER BY alert_date DESC
        """)

        rows = g.cursor.fetchall()

        alerts = []

        for r in rows:

            alerts.append({

                "alert_id": r[0],

                "mother_id": r[1],

                "child_id": r[2],

                "alert_type": r[3],

                "message": r[4],

                "alert_date": str(r[5]),

                "status": r[6] or "Pending"

            })

        return jsonify(alerts)

    except Exception as e:

        return jsonify({
            "error": str(e)
        }), 500


# ============================================================
# UPDATE ALERT STATUS (PHC Dashboard "Action Taken")
# ============================================================

@app.route("/update_alert_status/<int:alert_id>", methods=["PUT"])
def update_alert_status(alert_id):

    try:

        data = request.get_json() or {}

        status = data.get("status", "Action Taken")

        g.cursor.execute("""
            UPDATE alert
            SET status = %s
            WHERE alert_id = %s
        """, (status, alert_id))

        g.db.commit()

        return jsonify({
            "message": "Alert status updated",
            "status": "SUCCESS"
        }), 200

    except Exception as e:

        return jsonify({
            "error": str(e)
        }), 500


# ============================================================
# ALL HEALTH RECORDS (PHC Dashboard "Health Reports")
# ============================================================

@app.route("/get_all_health_records", methods=["GET"])
def get_all_health_records():

    try:

        g.cursor.execute("""
            SELECT
                h.record_id,
                h.mother_id,
                m.name,
                m.village,
                h.Age,
                h.SystolicBP,
                h.DiastolicBP,
                h.BS,
                h.BodyTemp,
                h.HeartRate,
                h.RiskLevel
            FROM health_record h
            LEFT JOIN mother m ON m.mother_id = h.mother_id
            ORDER BY h.record_id DESC
        """)

        rows = g.cursor.fetchall()

        records = []

        for r in rows:

            records.append({
                "record_id": r[0],
                "mother_id": r[1],
                "mother_name": r[2],
                "village": r[3],
                "Age": r[4],
                "SystolicBP": r[5],
                "DiastolicBP": r[6],
                "BS": r[7],
                "BodyTemp": r[8],
                "HeartRate": r[9],
                "RiskLevel": r[10]
            })

        return jsonify(records)

    except Exception as e:

        return jsonify({
            "error": str(e)
        }), 500


# ============================================================
# DASHBOARD
# ============================================================

@app.route("/dashboard", methods=["GET"])
def dashboard():

    try:

        # Total mothers
        g.cursor.execute("""
            SELECT COUNT(*)
            FROM mother
        """)

        total_mothers = g.cursor.fetchone()[0]

        # Total children
        g.cursor.execute("""
            SELECT COUNT(*)
            FROM child
        """)

        total_children = g.cursor.fetchone()[0]

        # Total alerts
        g.cursor.execute("""
            SELECT COUNT(*)
            FROM alert
        """)

        total_alerts = g.cursor.fetchone()[0]

        # High risk cases
        g.cursor.execute("""
            SELECT COUNT(*)
            FROM health_record
            WHERE RiskLevel = 'High Risk'
        """)

        high_risk = g.cursor.fetchone()[0]

        # Overdue vaccinations
        g.cursor.execute("""
            SELECT COUNT(*)
            FROM vaccination
            WHERE status = 'Pending'
            AND due_date < CURDATE()
        """)

        overdue = g.cursor.fetchone()[0]

        return jsonify({

            "total_mothers": total_mothers,

            "total_children": total_children,

            "total_alerts": total_alerts,

            "high_risk_cases": high_risk,

            "overdue_vaccinations": overdue

        })

    except Exception as e:

        return jsonify({
            "error": str(e)
        }), 500


# ============================================================
# RUN SERVER
# ============================================================

if __name__ == "__main__":

    print("====================================")
    print("MaatriSakhi Backend Started")
    print("====================================")

    print(app.url_map)

    print("====================================")
    print("PHC Dashboard: http://127.0.0.1:5000/phc")
    print("====================================")

    app.run(
        host="0.0.0.0",
        port=5000,
        debug=True
    )