"""
notification_service.py
========================

Sends a PHC (Primary Health Centre) alert via SMS (Twilio) and email
(SMTP) whenever app.py (or reminder_scheduler.py) detects something
that needs the PHC's attention. Called as:

    send_phc_notification(alert_message)

Returns {"sms_sent": bool, "email_sent": bool} — these exact key
names matter, app.py reads notification_result["sms_sent"] and
["email_sent"] directly.

All credentials come from the existing .env file — nothing new to
configure here, this just uses the values that were already there:
    PHC_PHONE_NUMBER, PHC_EMAIL,
    TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, TWILIO_PHONE_NUMBER,
    EMAIL_ADDRESS, EMAIL_APP_PASSWORD, SMTP_SERVER, SMTP_PORT
"""

import os
import smtplib
from email.mime.text import MIMEText

from dotenv import load_dotenv
from twilio.base.exceptions import TwilioRestException
from twilio.rest import Client

load_dotenv()

PHC_PHONE_NUMBER = os.environ.get("PHC_PHONE_NUMBER")
PHC_EMAIL = os.environ.get("PHC_EMAIL")

TWILIO_ACCOUNT_SID = os.environ.get("TWILIO_ACCOUNT_SID")
TWILIO_AUTH_TOKEN = os.environ.get("TWILIO_AUTH_TOKEN")
TWILIO_PHONE_NUMBER = os.environ.get("TWILIO_PHONE_NUMBER")

EMAIL_ADDRESS = os.environ.get("EMAIL_ADDRESS")
EMAIL_APP_PASSWORD = os.environ.get("EMAIL_APP_PASSWORD")
SMTP_SERVER = os.environ.get("SMTP_SERVER", "smtp.gmail.com")
SMTP_PORT = int(os.environ.get("SMTP_PORT", "587"))


def _send_sms(message: str) -> bool:
    if not all([TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, TWILIO_PHONE_NUMBER, PHC_PHONE_NUMBER]):
        print("SMS skipped: Twilio/PHC phone env vars not fully set.")
        return False

    try:
        client = Client(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)
        client.messages.create(
            body=message,
            from_=TWILIO_PHONE_NUMBER,
            to=PHC_PHONE_NUMBER,
        )
        return True
    except TwilioRestException as e:
        print(f"SMS failed: {e}")
        return False


def _send_email(message: str) -> bool:
    if not all([EMAIL_ADDRESS, EMAIL_APP_PASSWORD, PHC_EMAIL]):
        print("Email skipped: email env vars not fully set.")
        return False

    try:
        msg = MIMEText(message)
        msg["Subject"] = "MaatriSakhi \u2014 PHC Alert"
        msg["From"] = EMAIL_ADDRESS
        msg["To"] = PHC_EMAIL

        with smtplib.SMTP(SMTP_SERVER, SMTP_PORT) as server:
            server.starttls()
            server.login(EMAIL_ADDRESS, EMAIL_APP_PASSWORD)
            server.send_message(msg)
        return True
    except smtplib.SMTPException as e:
        print(f"Email failed: {e}")
        return False


def send_phc_notification(alert_message: str) -> dict:
    """Sends alert_message to the PHC via SMS and email.
    Returns {"sms_sent": bool, "email_sent": bool}. Never raises \u2014
    a failed channel is logged and reported as False so the calling
    endpoint doesn't crash because a notification failed.
    """
    sms_sent = _send_sms(alert_message)
    email_sent = _send_email(alert_message)
    return {"sms_sent": sms_sent, "email_sent": email_sent}
